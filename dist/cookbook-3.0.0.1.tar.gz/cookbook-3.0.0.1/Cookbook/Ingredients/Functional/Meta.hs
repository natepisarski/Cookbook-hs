module Cookbook.Ingredients.Functional.Meta(module Cookbook.Ingredients.Functional.Break) where

import Cookbook.Ingredients.Functional.Break
