module Cookbook.Ingredients.Tupples.Meta(module Cookbook.Ingredients.Tupples.Look,
                                         module Cookbook.Ingredients.Tupples.Assemble) where

import Cookbook.Ingredients.Tupples.Look
import Cookbook.Ingredients.Tupples.Assemble
