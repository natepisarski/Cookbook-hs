module Cookbook.Project.Quill.Quill(tables,getTable,lookUp,createTable,updateTable,removeTable,tableToString) where

import qualified Cookbook.Essential.Continuous     as Ct
import qualified Cookbook.Ingredients.Lists.Modify as Md
import qualified Cookbook.Ingredients.Lists.Remove as Rm
import qualified Cookbook.Essential.Common         as Cm
import qualified Cookbook.Ingredients.Tupples.Look as Lk

-- All one lines, remove whitespace
prepare :: [String] -> String
prepare =  (++ "}").Cm.flt . map (flip Md.rm $  ' ')

getTables :: [Char] -> [([Char], [[Char]])]
getTables x = wrapped
  where names = Md.surroundedBy x ('}','{')
        items = Md.surroundedBy x ('{','}') 
        itemPairs = map ((flip Md.splitOn) ';') items
        wrapped = zip names itemPairs
        values = itemPairs

tokenize :: [a] -> [(a,a)]
tokenize [] = []
tokenize [x] = []
tokenize (x:y:xs) = (x,y) : tokenize xs

splitUp :: (String,[String]) -> (String,[(String,String)])
splitUp (a,b) = (a,tokenize (Cm.flt $ (map ((flip Md.splitOn) ':') b)))

tables :: [String] -> [(String, [(String, String)])]
tables = map splitUp . getTables . prepare

getTable :: [(String,[(String,String)])] -> String -> [[(String,String)]]
getTable a b = Lk.lookList a b

--           Database                      table     item      res
lookUp :: [(String,[(String,String)])] -> String -> String -> [String]
lookUp db tb it = Lk.lookList (Cm.flt (getTable db tb)) it

-- CRUD
createTable :: String -> (String,[(String,String)])
createTable x = (x,[])

updateTable :: (String,[(String,String)]) -> (String,String) -> (String,[(String,String)])
updateTable (dbn,db) it = (dbn,it:db)

removeTable :: [(String,[(String,String)])] -> String -> [(String,[(String,String)])]
removeTable ((name,dat):rest) toRemove = if name == toRemove then removeTable rest toRemove else (name,dat) : removeTable rest toRemove
                                                                                               
 -- Table writing
itToString :: (String,String) -> String
itToString (a,b) = a ++ ":" ++ b ++ ";"

tableToString :: (String,[(String,String)]) -> String
tableToString (name,dat) = Cm.flt $ "name{" : (map itToString dat) ++ ["}"]
